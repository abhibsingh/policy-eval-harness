"""
CartPole, written out rather than imported, so every physical parameter
is perturbable and the integration is visible.

Dynamics are the standard Barto, Sutton and Anderson cart pole, with
three additions that matter for evaluation:

  - friction on the cart and at the pole hinge
  - observation noise and whole step action delay
  - a force limit, so a policy cannot ask for infinite torque

State: [x, x_dot, theta, theta_dot], theta measured from upright.
"""

from dataclasses import dataclass
from collections import deque
import numpy as np


@dataclass
class EnvParams:
    gravity: float = 9.8
    mass_cart: float = 1.0
    mass_pole: float = 0.1
    pole_half_length: float = 0.5
    force_mag: float = 10.0
    tau: float = 0.02               # control period, s
    friction_cart: float = 0.0005
    friction_pole: float = 0.000002
    x_limit: float = 2.4            # m, rail length
    theta_limit: float = 0.21       # rad, ~12 degrees
    obs_noise_std: float = 0.0      # rad and m
    action_delay_steps: int = 0
    max_steps: int = 500


class CartPole:
    def __init__(self, p: EnvParams = EnvParams(), seed: int = 0):
        self.p = p
        self.rng = np.random.default_rng(seed)
        self.reset()

    def reset(self):
        self.state = self.rng.uniform(-1.0, 1.0, size=4) * np.array([0.5, 0.5, 0.12, 0.5])
        self.steps = 0
        n = self.p.action_delay_steps + 1
        self.action_buf = deque([0.0] * n, maxlen=n)
        return self.observe()

    def observe(self) -> np.ndarray:
        obs = self.state.copy()
        if self.p.obs_noise_std > 0:
            obs = obs + self.rng.normal(0.0, self.p.obs_noise_std, size=4)
        return obs

    def step(self, action: float):
        p = self.p
        self.action_buf.append(float(np.clip(action, -1.0, 1.0)))
        force = self.action_buf[0] * p.force_mag

        x, x_dot, th, th_dot = self.state
        total_mass = p.mass_cart + p.mass_pole
        pole_ml = p.mass_pole * p.pole_half_length
        cos_th, sin_th = np.cos(th), np.sin(th)

        temp = (force + pole_ml * th_dot ** 2 * sin_th
                - p.friction_cart * np.sign(x_dot)) / total_mass
        th_acc = ((p.gravity * sin_th - cos_th * temp
                   - p.friction_pole * th_dot / pole_ml)
                  / (p.pole_half_length
                     * (4.0 / 3.0 - p.mass_pole * cos_th ** 2 / total_mass)))
        x_acc = temp - pole_ml * th_acc * cos_th / total_mass

        # semi implicit Euler, same as the classic implementation
        x_dot += p.tau * x_acc
        x += p.tau * x_dot
        th_dot += p.tau * th_acc
        th += p.tau * th_dot
        self.state = np.array([x, x_dot, th, th_dot])
        self.steps += 1

        failed = bool(abs(x) > p.x_limit or abs(th) > p.theta_limit)
        timeout = self.steps >= p.max_steps
        reward = 1.0
        return self.observe(), reward, failed, timeout

    def rollout(self, policy, seed: int = None):
        if seed is not None:
            self.rng = np.random.default_rng(seed)
        obs = self.reset()
        total = 0.0
        while True:
            a = policy(obs)
            obs, r, failed, timeout = self.step(a)
            total += r
            if failed or timeout:
                return {
                    "return": total,
                    "steps": self.steps,
                    "failed": failed,
                    "final_x": float(self.state[0]),
                    "final_theta": float(self.state[2]),
                }

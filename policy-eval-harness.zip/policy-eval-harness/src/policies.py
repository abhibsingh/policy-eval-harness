"""
Two policies for the same task, produced in completely different ways.

  - a hand written PD controller, which I can explain line by line
  - a linear policy trained by the cross entropy method, which I cannot

That contrast is the point. The learned one scores better on the task it
was trained on. The evaluation harness exists to ask what else is true.
"""

import numpy as np


def pd_policy(gains=(0.6, 1.2, 8.0, 1.6)):
    """
    Classic nested loop: drive the pole upright, and let the cart position
    bias the angle target so it does not run off the end of the rail.
    """
    kx, kxd, kth, kthd = gains

    def policy(obs):
        x, x_dot, th, th_dot = obs
        th_target = -(kx * x + kxd * x_dot) * 0.05
        u = kth * (th - th_target) + kthd * th_dot
        return float(np.clip(u, -1.0, 1.0))

    return policy


def linear_policy(weights):
    w = np.asarray(weights, dtype=float)

    def policy(obs):
        return float(np.clip(np.dot(w, obs), -1.0, 1.0))

    return policy


def train_cem(env_factory, n_iter=30, pop=40, elite_frac=0.2,
              train_seeds=(0, 1, 2), seed=0, verbose=False):
    """
    Cross entropy method over linear policy weights.

    Deliberately trained on only three fixed seeds and the nominal plant.
    That is a realistic amount of training diversity for a small project,
    and it is exactly the condition that makes the evaluation interesting.
    """
    rng = np.random.default_rng(seed)
    mu = np.zeros(4)
    sigma = np.ones(4) * 1.5
    n_elite = max(2, int(pop * elite_frac))
    history = []

    for it in range(n_iter):
        samples = rng.normal(mu, sigma, size=(pop, 4))
        scores = []
        for w in samples:
            pol = linear_policy(w)
            returns = [env_factory().rollout(pol, seed=s)["return"] for s in train_seeds]
            scores.append(np.mean(returns))
        scores = np.array(scores)

        elite = samples[np.argsort(scores)[-n_elite:]]
        mu = elite.mean(axis=0)
        sigma = elite.std(axis=0) + 0.01
        history.append(float(scores.max()))
        if verbose:
            print(f"iter {it:02d}  best {scores.max():7.1f}  mean {scores.mean():7.1f}")

    return mu, history

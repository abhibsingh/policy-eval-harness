"""
How do you tell whether a policy actually improved?

Not by running it once. Not by comparing mean return on the conditions it
was trained on. This harness does four things that a single number cannot:

  1. many seeds, and reports a confidence interval, not a point estimate
  2. success rate alongside mean return, because they disagree
  3. a perturbation grid, so out of distribution behaviour is visible
  4. a bootstrap comparison, so "better" has to clear the noise floor

Run with: python src/evaluate.py
"""

import os
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from env import CartPole, EnvParams
from policies import pd_policy, linear_policy, train_cem

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PLOTS, DATA = os.path.join(ROOT, "plots"), os.path.join(ROOT, "data")
os.makedirs(PLOTS, exist_ok=True)
os.makedirs(DATA, exist_ok=True)

N_EVAL_SEEDS = 200
SUCCESS_STEPS = 500


def make_env(**overrides):
    p = EnvParams(**overrides)
    return lambda: CartPole(p)


def evaluate(policy, env_factory, n_seeds=N_EVAL_SEEDS, seed_offset=10_000):
    rows = [env_factory().rollout(policy, seed=seed_offset + i) for i in range(n_seeds)]
    returns = np.array([r["return"] for r in rows])
    success = np.array([r["steps"] >= SUCCESS_STEPS and not r["failed"] for r in rows])
    return {
        "mean_return": float(returns.mean()),
        "ci95": float(1.96 * returns.std(ddof=1) / np.sqrt(len(returns))),
        "median_return": float(np.median(returns)),
        "p10_return": float(np.percentile(returns, 10)),
        "success_rate": float(success.mean()),
        "returns": returns,
    }


def bootstrap_diff(a_returns, b_returns, n_boot=5000, seed=0):
    """Is A better than B, or is that the seeds talking?"""
    rng = np.random.default_rng(seed)
    diffs = np.empty(n_boot)
    for i in range(n_boot):
        ra = rng.choice(a_returns, size=len(a_returns), replace=True)
        rb = rng.choice(b_returns, size=len(b_returns), replace=True)
        diffs[i] = ra.mean() - rb.mean()
    lo, hi = np.percentile(diffs, [2.5, 97.5])
    return {
        "mean_diff": float(diffs.mean()),
        "ci95_low": float(lo),
        "ci95_high": float(hi),
        "significant": bool(lo > 0 or hi < 0),
    }


def main():
    report = {}

    print("training CEM policy on the nominal plant, 3 seeds ...")
    weights, history = train_cem(make_env(), verbose=False)
    report["cem_weights"] = [round(float(w), 4) for w in weights]
    report["cem_training_best_per_iter"] = [round(h, 1) for h in history]

    policies = {
        "pd_handwritten": pd_policy(),
        "cem_learned": linear_policy(weights),
    }

    # ---- nominal, many seeds
    report["nominal"] = {}
    nominal_returns = {}
    for name, pol in policies.items():
        res = evaluate(pol, make_env())
        nominal_returns[name] = res.pop("returns")
        report["nominal"][name] = {k: round(v, 3) for k, v in res.items()}

    report["nominal_comparison"] = bootstrap_diff(
        nominal_returns["cem_learned"], nominal_returns["pd_handwritten"]
    )

    # ---- perturbation grid
    grid = {
        "mass_pole": [0.1, 0.5, 1.0, 2.0, 4.0],
        "pole_half_length": [0.25, 0.5, 1.0, 1.5, 2.0],
        "obs_noise_std": [0.0, 0.02, 0.05, 0.1, 0.2],
        "action_delay_steps": [0, 1, 2, 4, 6],
        "friction_cart": [0.0005, 0.05, 0.2, 0.5],
    }
    report["sweeps"] = {}
    for axis, values in grid.items():
        report["sweeps"][axis] = {}
        for name, pol in policies.items():
            rows = []
            for v in values:
                res = evaluate(pol, make_env(**{axis: v}), n_seeds=60)
                res.pop("returns")
                rows.append({"value": v, **{k: round(x, 3) for k, x in res.items()}})
            report["sweeps"][axis][name] = rows

    # ---- aggregate robustness
    for name in policies:
        rates = [row["success_rate"]
                 for axis in grid for row in report["sweeps"][axis][name]]
        report.setdefault("summary", {})[name] = {
            "nominal_success_rate": report["nominal"][name]["success_rate"],
            "mean_success_rate_across_grid": round(float(np.mean(rates)), 3),
            "worst_case_success_rate": round(float(np.min(rates)), 3),
            "cases_below_50pct": int(np.sum(np.array(rates) < 0.5)),
            "total_cases": len(rates),
        }

    with open(os.path.join(DATA, "eval_report.json"), "w") as f:
        json.dump(report, f, indent=2)

    # ---- plot 1: return distributions, not means
    fig, ax = plt.subplots(figsize=(9, 4.2))
    ax.hist(nominal_returns["pd_handwritten"], bins=30, alpha=0.6, label="PD handwritten")
    ax.hist(nominal_returns["cem_learned"], bins=30, alpha=0.6, label="CEM learned")
    ax.set_xlabel("episode return"); ax.set_ylabel("count")
    ax.set_title(f"Return distribution over {N_EVAL_SEEDS} seeds, nominal plant")
    ax.legend(fontsize=8); ax.grid(alpha=0.3)
    fig.tight_layout(); fig.savefig(os.path.join(PLOTS, "01_distribution.png"), dpi=130); plt.close(fig)

    # ---- plot 2: success rate across perturbations
    axes_to_plot = ["mass_pole", "pole_half_length", "obs_noise_std", "action_delay_steps"]
    fig, axs = plt.subplots(1, 4, figsize=(16, 3.8))
    for ax, axis in zip(axs, axes_to_plot):
        for name in policies:
            rows = report["sweeps"][axis][name]
            ax.plot([r["value"] for r in rows], [r["success_rate"] for r in rows], "o-", label=name)
        ax.set_xlabel(axis); ax.set_ylabel("success rate"); ax.set_ylim(-0.05, 1.05)
        ax.grid(alpha=0.3); ax.legend(fontsize=7)
    fig.suptitle("Trained on the nominal plant only. Evaluated everywhere else.")
    fig.tight_layout(); fig.savefig(os.path.join(PLOTS, "02_robustness.png"), dpi=130); plt.close(fig)

    print(json.dumps({"nominal": report["nominal"],
                      "comparison": report["nominal_comparison"],
                      "summary": report["summary"]}, indent=2))


if __name__ == "__main__":
    main()

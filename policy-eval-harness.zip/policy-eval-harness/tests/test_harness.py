import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import numpy as np
from env import CartPole, EnvParams
from policies import pd_policy, linear_policy
from evaluate import evaluate, bootstrap_diff, make_env


def test_rollouts_are_reproducible_given_a_seed():
    pol = pd_policy()
    a = CartPole(EnvParams()).rollout(pol, seed=42)
    b = CartPole(EnvParams()).rollout(pol, seed=42)
    assert a == b


def test_different_seeds_give_different_episodes():
    pol = linear_policy([0.1, 0.1, 0.1, 0.1])
    outs = {CartPole(EnvParams()).rollout(pol, seed=s)["return"] for s in range(20)}
    assert len(outs) > 1


def test_zero_action_policy_falls_over():
    res = CartPole(EnvParams()).rollout(lambda obs: 0.0, seed=1)
    assert res["failed"]
    assert res["steps"] < EnvParams().max_steps


def test_pd_policy_balances_nominal_plant():
    res = evaluate(pd_policy(), make_env(), n_seeds=20)
    assert res["success_rate"] == 1.0


def test_observation_noise_actually_perturbs_observations():
    env = CartPole(EnvParams(obs_noise_std=0.1), seed=0)
    env.reset()
    assert not np.allclose(env.observe(), env.observe())


def test_action_delay_shifts_the_applied_force():
    p = EnvParams(action_delay_steps=3)
    env = CartPole(p, seed=0)
    env.reset()
    for _ in range(2):
        env.step(1.0)
    # the delayed buffer should still be feeding zeros through
    assert env.action_buf[0] == 0.0


def test_bootstrap_detects_a_real_difference():
    rng = np.random.default_rng(0)
    a = rng.normal(500, 10, 200)
    b = rng.normal(400, 10, 200)
    assert bootstrap_diff(a, b)["significant"]


def test_bootstrap_rejects_noise():
    rng = np.random.default_rng(0)
    a = rng.normal(450, 50, 200)
    b = rng.normal(450, 50, 200)
    assert not bootstrap_diff(a, b)["significant"]
